define(['jquery'], function ($) {
  var CustomWidget = function () {
    var self = this;
    
    // ==========================================
    // PENGATURAN KONEKSI KE CLOUDFLARE WORKER
    // ==========================================
    var WORKER_API_URL = "https://[NAMA_WORKER_ANDA].workers.dev/api/generate-reply";
    var WIDGET_SECRET_KEY = "GANTI_DENGAN_KUNCI_RAHASIA_YANG_SAMA_DI_CLOUDFLARE";
    // ==========================================

    this.callbacks = {
      render: function () {
        var $rightPanel = $('.card-right-top-tabs');
        if ($rightPanel.length === 0) return true;

        if ($('.moemtaz-ai-btn-container').length === 0) {
          var buttonHtml = `
            <div class="moemtaz-ai-btn-container">
              <button class="moemtaz-ai-btn button-input button-input_blue" type="button">
                <span class="button-input-inner">
                  <span class="button-input-inner__text">Ask Moemtaz AI</span>
                </span>
              </button>
            </div>
          `;
          // Menyuntikkan tombol di bawah tab panel kanan
          $('.card-right-bottom').prepend(buttonHtml);
        }

        return true;
      },
      init: function () {
        return true;
      },
      bind_actions: function () {
        $(document).off('click', '.moemtaz-ai-btn').on('click', '.moemtaz-ai-btn', function () {
          var leadId = AMOCRM.data.current_card.id;
          if (!leadId) {
            alert("Gagal membaca Lead ID.");
            return;
          }

          var $btnText = $(this).find('.button-input-inner__text');
          var originalText = $btnText.text();
          
          $btnText.text("Sedang Berpikir...");
          $(this).addClass('button-input-disabled');

          $.ajax({
            url: WORKER_API_URL,
            type: 'POST',
            contentType: 'application/json',
            headers: {
              "X-Widget-Secret": WIDGET_SECRET_KEY
            },
            data: JSON.stringify({
              lead_id: leadId
            }),
            success: function (res) {
              $btnText.text("AI Berhasil Dipicu!");
              setTimeout(function() {
                $btnText.text(originalText);
                $('.moemtaz-ai-btn').removeClass('button-input-disabled');
              }, 3000);
            },
            error: function (err) {
              console.error("Moemtaz AI Error:", err);
              alert("Gagal memicu AI. Cek console log atau konfigurasi URL/Secret Key.");
              $btnText.text(originalText);
              $('.moemtaz-ai-btn').removeClass('button-input-disabled');
            }
          });
        });

        return true;
      },
      settings: function () {
        return true;
      },
      onSave: function () {
        return true;
      },
      destroy: function () {
        $('.moemtaz-ai-btn-container').remove();
      }
    };
    return this;
  };

  return CustomWidget;
});
